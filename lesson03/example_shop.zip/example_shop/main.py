# ---------------пример по работе с БД Магазин---------------------- #

'''
создать БД  # config.py
создать таблицу в бд # config.py
наполнить таблицу записями
Код для работы с запросами select
'''

from config import *


def add_client(name, birth_date, email, phone_number):
    with sqlite3.connect('shop.db') as con:  # установка соединения
        cursor = con.cursor()

        cursor.executescript(f'''INSERT INTO clients (name, birth_date, email, phone_number) VALUES
        ('{name}', '{birth_date}', '{email}', '{phone_number}');
        ''')

def show_clients():
    with sqlite3.connect('shop.db') as con:  # установка соединения
        cursor = con.cursor()

        cursor.execute(f'''
        SELECT * FROM Clients
        ''')
        rows = cursor.fetchall()
        for row in rows:
            print(row)


if __name__ == '__main__':
    while True:
        command = input( '''
1. Создать клиента
2. Просмотреть клиентов
0. выйти из программы
''')
        match command:
            case '1':
                pass
#                 clients =[('Петров Петр', '1985-08-20', 'petrov@example.com', '987-654-3210'),
# ('Сидорова Елена', '1995-02-10', 'sidorova@example.com', '111-222-3333'),
# ('Смирнова Ольга', '1980-11-25', 'smirnova@example.com', '444-555-6666'),
# ('Козлова Анна', '1975-07-30', 'kozlova@example.com', '777-888-9999'),
# ('Новиков Александр', '1992-04-05', 'novikov@example.com', '000-111-2222'),
# ('Морозов Владимир', '1987-09-12', 'morozov@example.com', '333-444-5555'),
# ('Кузнецова Мария', '1998-03-20', 'kuznetsova@example.com', '666-777-8888'),
# ('Федоров Дмитрий', '1983-06-18', 'fedorov@example.com', '999-000-1111'),
# ('Алексеева Наталья', '1979-12-08', 'alekseeva@example.com', '222-333-4444')]
#                 for client in clients:
#                     add_client(*client)
            case '2':
                show_clients()
            case '0':
                break